from __future__ import annotations

from dataclasses import asdict
import json

import numpy as np
import pandas as pd
import streamlit as st

from widgets import percent_slider

from core.models import (
    SystemInputs,
    CapexInputs,
    OpexInputs,
    PowerInputs,
    ModelInputs,
)
from core.timeseries import (
    make_demo_timeseries,
    validate_timeseries,
    parse_timeseries_text,
    timeseries_to_text,
)
from core.simulation import build_dispatch
from core.finance import compute_lcoh

import plotly.graph_objects as go

import locale

locale.setlocale(locale.LC_ALL, "de_DE.UTF-8")

def de_number(value, decimals=2):
    if value is None:
        return "-"
    return f"{value:,.{decimals}f}".replace(",", "X").replace(".", ",").replace("X", ".")

st.set_page_config(page_title="Berechnungstool LCOH", layout="wide")


# ============================================================
# Session-State Initialisierung
# ============================================================

def init_ui_state() -> None:
    if "ui_initialized" in st.session_state:
        return

    # Defaults aus Dataclasses
    s = SystemInputs()
    c = CapexInputs()
    o = OpexInputs()
    p = PowerInputs()

    # System
    st.session_state.commissioning_year = s.commissioning_year
    st.session_state.project_lifetime_years = s.project_lifetime_years
    st.session_state.electrolyzer_power_kw = s.electrolyzer_power_kw
    st.session_state.system_power_kw = s.system_power_kw
    st.session_state.min_load_fraction = s.min_load_fraction * 100
    st.session_state.avg_efficiency_h2_per_el = s.avg_efficiency_h2_per_el * 100
    st.session_state.stack_lifetime_years = s.stack_lifetime_years
    st.session_state.degradation_per_year = s.degradation_per_year

    # CAPEX
    st.session_state.epc_eur_per_kw = c.epc_eur_per_kw
    st.session_state.bop_eur_per_kw = c.bop_eur_per_kw
    st.session_state.hochbau_eur_per_kw = c.hochbau_eur_per_kw
    st.session_state.tiefbau_eur_per_kw = c.tiefbau_eur_per_kw
    st.session_state.individual_specific_eur_per_kw = c.individual_specific_eur_per_kw
    st.session_state.individual_fixed_eur = c.individual_fixed_eur

    st.session_state.waste_heat_enabled = c.waste_heat_enabled
    st.session_state.waste_heat_system_eur_per_kw = c.waste_heat_system_eur_per_kw

    st.session_state.oxygen_enabled = c.oxygen_enabled
    st.session_state.oxygen_system_eur_per_kw = c.oxygen_system_eur_per_kw

    st.session_state.compression_enabled = c.compression_enabled
    st.session_state.compressor_system_eur_per_kw = c.compressor_system_eur_per_kw

    st.session_state.battery_enabled = c.battery_enabled
    st.session_state.battery_capacity_factor_kwh_per_kw = c.battery_capacity_factor_kwh_per_kw
    st.session_state.battery_power_kw = c.battery_power_kw
    st.session_state.battery_invest_eur_per_kwh = c.battery_invest_eur_per_kwh

    st.session_state.stack_replacement_specific_eur_per_kw = c.stack_replacement_specific_eur_per_kw
    st.session_state.discount_rate = c.discount_rate
    st.session_state.debt_interest_rate = c.debt_interest_rate
    st.session_state.equity_share = c.equity_share

    # OPEX
    st.session_state.maintenance_share_of_capex = o.maintenance_share_of_capex * 100
    st.session_state.maintenance_escalation_per_year = o.maintenance_escalation_per_year * 100

    st.session_state.personnel_eur_per_year = o.personnel_eur_per_year
    st.session_state.personnel_escalation_per_year = o.personnel_escalation_per_year * 100

    st.session_state.reserve_remaining_plant_share_of_capex = o.reserve_remaining_plant_share_of_capex * 100
    st.session_state.reserve_decommissioning_share_of_capex = o.reserve_decommissioning_share_of_capex * 100
    st.session_state.reserve_escalation_per_year = o.reserve_escalation_per_year * 100

    st.session_state.freshwater_price_eur_per_m3 = o.freshwater_price_eur_per_m3
    st.session_state.freshwater_treatment_price_eur_per_m3 = o.freshwater_treatment_price_eur_per_m3
    st.session_state.wastewater_price_eur_per_m3 = o.wastewater_price_eur_per_m3
    st.session_state.water_escalation_per_year = o.water_escalation_per_year * 100

    st.session_state.individual_opex_share_of_capex = o.individual_opex_share_of_capex * 100
    st.session_state.individual_opex_escalation_per_year = o.individual_opex_escalation_per_year * 100

    # Power
    st.session_state.baseload_enabled = p.baseload_enabled
    st.session_state.baseload_kw = p.baseload_kw
    st.session_state.baseload_price_eur_per_mwh = p.baseload_price_eur_per_mwh
    st.session_state.baseload_price_escalation_per_year = p.baseload_price_escalation_per_year * 100

    st.session_state.ppa_pv_enabled = p.ppa_pv_enabled
    st.session_state.ppa_pv_capacity_kw = p.ppa_pv_capacity_kw
    st.session_state.ppa_pv_price_eur_per_mwh = p.ppa_pv_price_eur_per_mwh

    st.session_state.ppa_wind_enabled = p.ppa_wind_enabled
    st.session_state.ppa_wind_capacity_kw = p.ppa_wind_capacity_kw
    st.session_state.ppa_wind_price_eur_per_mwh = p.ppa_wind_price_eur_per_mwh

    st.session_state.ppa_price_escalation_per_year = p.ppa_price_escalation_per_year * 100

    st.session_state.spot_purchase_enabled = p.spot_purchase_enabled
    st.session_state.spot_purchase_price_limit_enabled = p.spot_purchase_price_limit_enabled
    st.session_state.spot_purchase_price_limit_eur_per_mwh = p.spot_purchase_price_limit_eur_per_mwh
    st.session_state.spot_sale_enabled = p.spot_sale_enabled
    st.session_state.spot_sale_price_limit_enabled = p.spot_sale_price_limit_enabled
    st.session_state.spot_sale_min_price_eur_per_mwh = p.spot_sale_min_price_eur_per_mwh

    demo_ts = make_demo_timeseries()
    st.session_state.timeseries_df = demo_ts.copy()
    st.session_state.pv_profile_text = timeseries_to_text(demo_ts["pv_kwh_per_kw"])
    st.session_state.wind_profile_text = timeseries_to_text(demo_ts["wind_kwh_per_kw"])
    st.session_state.spot_price_text = timeseries_to_text(demo_ts["day_ahead_eur_per_mwh"])

    # Weitere Zustände
    st.session_state.result_bundle = None
    st.session_state.ui_initialized = True


def build_model_inputs_from_ui() -> ModelInputs:
    system = SystemInputs(
        commissioning_year=int(st.session_state.commissioning_year),
        project_lifetime_years=int(st.session_state.project_lifetime_years),
        electrolyzer_power_kw=float(st.session_state.electrolyzer_power_kw),
        system_power_kw=float(st.session_state.system_power_kw),
        min_load_fraction=float(st.session_state.min_load_fraction) / 100,
        avg_efficiency_h2_per_el=float(st.session_state.avg_efficiency_h2_per_el) / 100,
        stack_lifetime_years=int(st.session_state.stack_lifetime_years),
        degradation_per_year=float(st.session_state.degradation_per_year),
    )

    capex = CapexInputs(
        epc_eur_per_kw=float(st.session_state.epc_eur_per_kw),
        bop_eur_per_kw=float(st.session_state.bop_eur_per_kw),
        hochbau_eur_per_kw=float(st.session_state.hochbau_eur_per_kw),
        tiefbau_eur_per_kw=float(st.session_state.tiefbau_eur_per_kw),
        individual_specific_eur_per_kw=float(st.session_state.individual_specific_eur_per_kw),
        individual_fixed_eur=float(st.session_state.individual_fixed_eur),

        waste_heat_enabled=bool(st.session_state.waste_heat_enabled),
        waste_heat_system_eur_per_kw=float(st.session_state.waste_heat_system_eur_per_kw),

        oxygen_enabled=bool(st.session_state.oxygen_enabled),
        oxygen_system_eur_per_kw=float(st.session_state.oxygen_system_eur_per_kw),

        compression_enabled=bool(st.session_state.compression_enabled),
        compressor_system_eur_per_kw=float(st.session_state.compressor_system_eur_per_kw),

        battery_enabled=bool(st.session_state.battery_enabled),
        battery_capacity_factor_kwh_per_kw=float(st.session_state.battery_capacity_factor_kwh_per_kw),
        battery_power_kw=float(st.session_state.battery_power_kw),
        battery_invest_eur_per_kwh=float(st.session_state.battery_invest_eur_per_kwh),

        stack_replacement_specific_eur_per_kw=float(st.session_state.stack_replacement_specific_eur_per_kw),
        discount_rate=float(st.session_state.discount_rate),
        debt_interest_rate=float(st.session_state.debt_interest_rate),
        equity_share=float(st.session_state.equity_share),
    )

    opex = OpexInputs(
        maintenance_share_of_capex=float(st.session_state.maintenance_share_of_capex) / 100.0,
        maintenance_escalation_per_year=float(st.session_state.maintenance_escalation_per_year) / 100.0,

        personnel_eur_per_year=float(st.session_state.personnel_eur_per_year),
        personnel_escalation_per_year=float(st.session_state.personnel_escalation_per_year) / 100.0,

        reserve_remaining_plant_share_of_capex=float(st.session_state.reserve_remaining_plant_share_of_capex) / 100.0,
        reserve_decommissioning_share_of_capex=float(st.session_state.reserve_decommissioning_share_of_capex) / 100.0,
        reserve_escalation_per_year=float(st.session_state.reserve_escalation_per_year) / 100.0,

        freshwater_price_eur_per_m3=float(st.session_state.freshwater_price_eur_per_m3),
        freshwater_treatment_price_eur_per_m3=float(st.session_state.freshwater_treatment_price_eur_per_m3),
        wastewater_price_eur_per_m3=float(st.session_state.wastewater_price_eur_per_m3),
        water_escalation_per_year=float(st.session_state.water_escalation_per_year) / 100.0,

        individual_opex_share_of_capex=float(st.session_state.individual_opex_share_of_capex) / 100.0,
        individual_opex_escalation_per_year=float(st.session_state.individual_opex_escalation_per_year) / 100.0,
    )

    power = PowerInputs(
        baseload_enabled=bool(st.session_state.baseload_enabled),
        baseload_kw=float(st.session_state.baseload_kw),
        baseload_price_eur_per_mwh=float(st.session_state.baseload_price_eur_per_mwh),
        baseload_price_escalation_per_year=float(st.session_state.baseload_price_escalation_per_year) / 100.0,

        ppa_pv_enabled=bool(st.session_state.ppa_pv_enabled),
        ppa_pv_capacity_kw=float(st.session_state.ppa_pv_capacity_kw),
        ppa_pv_price_eur_per_mwh=float(st.session_state.ppa_pv_price_eur_per_mwh),

        ppa_wind_enabled=bool(st.session_state.ppa_wind_enabled),
        ppa_wind_capacity_kw=float(st.session_state.ppa_wind_capacity_kw),
        ppa_wind_price_eur_per_mwh=float(st.session_state.ppa_wind_price_eur_per_mwh),

        ppa_price_escalation_per_year=float(st.session_state.ppa_price_escalation_per_year) / 100.0,

        spot_purchase_enabled=bool(st.session_state.spot_purchase_enabled),
        spot_purchase_price_limit_enabled=bool(st.session_state.spot_purchase_price_limit_enabled),
        spot_purchase_price_limit_eur_per_mwh=float(st.session_state.spot_purchase_price_limit_eur_per_mwh),

        spot_sale_enabled=bool(st.session_state.spot_sale_enabled),
        spot_sale_price_limit_enabled=bool(st.session_state.spot_sale_price_limit_enabled),
        spot_sale_min_price_eur_per_mwh=float(st.session_state.spot_sale_min_price_eur_per_mwh),
    )

    return ModelInputs(system=system, capex=capex, opex=opex, power=power)

def read_numeric_csv_series(uploaded_file, expected_length: int = 8760) -> np.ndarray:
    df = pd.read_csv(uploaded_file)
    numeric_cols = df.select_dtypes(include=["number"]).columns.tolist()

    if not numeric_cols:
        raise ValueError("CSV enthält keine numerische Spalte.")

    values = df[numeric_cols[0]].to_numpy(dtype=float)

    if len(values) != expected_length:
        raise ValueError(f"Es wurden {len(values)} Werte gefunden, erwartet werden {expected_length}.")

    if np.any(~np.isfinite(values)):
        raise ValueError("Die Zeitreihe enthält ungültige Werte.")

    return values

init_ui_state()


# ============================================================
# Sidebar
# ============================================================


if st.sidebar.button("Berechnung starten", type="primary", use_container_width=True):
    try:
        model_inputs = build_model_inputs_from_ui()
        dispatch_df = build_dispatch(model_inputs, st.session_state.timeseries_df)
        results = compute_lcoh(model_inputs, dispatch_df)

        st.session_state.result_bundle = {
            "inputs": model_inputs,
            "dispatch": dispatch_df,
            "results": results,
        }
    except Exception as e:
        st.sidebar.error(f"Fehler: {e}")

st.sidebar.title("Key Performance Indicators")
st.sidebar.divider()

if st.session_state.result_bundle is None:
    st.sidebar.info("Noch keine Ergebnisse verfügbar.")
else:
    r = st.session_state.result_bundle["results"]
    st.sidebar.metric("LCOH [€/kg]", de_number(r["lcoh_eur_per_kg"], 2))
    st.sidebar.metric("LCOH [ct/kWh]", de_number(r["lcoh_ct_per_kwh"], 2))
    st.sidebar.metric("H₂-Produktion [kg/a]", de_number(r["annual_h2_kg"], 0))
    st.sidebar.metric("Ely-Stromverbrauch [MWh/a]", de_number(r["annual_ely_mwh"], 0))


# ============================================================
# Hauptlayout
# ============================================================

st.title("Berechnungstool LCOH")
st.caption(
    "Tool zur Berechnung von Wasserstoffgestehungskosten (Levelised Cost of Hydrogen)"
)

tabs = st.tabs(
    [
        "1) System",
        "2) CAPEX",
        "3) OPEX",
        "4) Strom & Zeitreihen",
        "5) Ergebnisse",
    ]
)


# ============================================================
# Tab 1: System
# ============================================================

with tabs[0]:
    st.subheader("Systemparameter")

    with st.expander("Allgemeine Projektparameter", expanded=True):
        c1, c2, c3 = st.columns(3)

        with c1:
            st.number_input(
                "Inbetriebnahmejahr",
                min_value=2000,
                max_value=2100,
                step=1,
                key="commissioning_year",
            )

        with c2:
            st.number_input(
                "Projektlaufzeit [a]",
                min_value=1,
                max_value=50,
                step=1,
                key="project_lifetime_years",
            )

    with st.expander("Leistungsdaten", expanded=True):
        c1, c2, c3 = st.columns(3)

        with c1:
            st.number_input(
                "Elektrolyseurleistung [kW]",
                min_value=1.0,
                max_value=1_000_000.0,
                step=100.0,
                key="electrolyzer_power_kw",
            )

        with c2:
            st.number_input(
                "Systemleistung [kW]",
                min_value=1.0,
                max_value=1_000_000.0,
                step=100.0,
                key="system_power_kw",
            )

        with c3:
            percent_slider(
                "Mindestlast",
                key="min_load_fraction",
            )

    with st.expander("Wirkungsgrad & Degradation", expanded=True):
        c1, c2, c3 = st.columns(3)

        with c1:
            percent_slider(
                "Mittlere Effizienz η",
                key="avg_efficiency_h2_per_el",
            )

        with c2:
            st.number_input(
                "Stack-Lebensdauer [a]",
                min_value=1,
                max_value=30,
                step=1,
                key="stack_lifetime_years",
            )

        with c3:
            percent_slider(
                "Degradation pro Jahr",
                key="degradation_per_year",
            )


# ============================================================
# Tab 2: CAPEX
# ============================================================

with tabs[1]:
    st.subheader("CAPEX & Finanzierung")

    with st.expander("Allgemeine CAPEX", expanded=True):
        c1, c2 = st.columns(2)

        with c1:
            st.number_input(
                "Engineering, Procurement & Construction [€/kW]",
                min_value=0.0,
                max_value=100_000.0,
                step=10.0,
                key="epc_eur_per_kw",
            )
            st.number_input(
                "Hochbau [€/kW]",
                min_value=0.0,
                max_value=100_000.0,
                step=10.0,
                key="hochbau_eur_per_kw",
            )
            st.number_input(
                "Individuelle CAPEX pro Leistung [€/kW]",
                min_value=0.0,
                max_value=100_000.0,
                step=10.0,
                key="individual_specific_eur_per_kw",
            )

        with c2:
            st.number_input(
                "Peripherie / Balance of Plant [€/kW]",
                min_value=0.0,
                max_value=100_000.0,
                step=10.0,
                key="bop_eur_per_kw",
            )
            st.number_input(
                "Tiefbau [€/kW]",
                min_value=0.0,
                max_value=100_000.0,
                step=10.0,
                key="tiefbau_eur_per_kw",
            )
            st.number_input(
                "Individuelle CAPEX pauschal [€]",
                min_value=0.0,
                max_value=1_000_000_000.0,
                step=10_000.0,
                key="individual_fixed_eur",
            )

    with st.expander("Abwärme", expanded=False):
        c1, c2 = st.columns(2)
        with c1:
            st.checkbox("Abwärme nutzbar", key="waste_heat_enabled")
        with c2:
            st.number_input(
                "Abwärmesystemkosten [€/kW]",
                min_value=0.0,
                max_value=100_000.0,
                step=10.0,
                key="waste_heat_system_eur_per_kw",
                disabled=not st.session_state.waste_heat_enabled,
            )

    with st.expander("Sauerstoff", expanded=False):
        c1, c2 = st.columns(2)
        with c1:
            st.checkbox("Sauerstoff nutzbar", key="oxygen_enabled")
        with c2:
            st.number_input(
                "Sauerstoffsystemkosten [€/kW]",
                min_value=0.0,
                max_value=100_000.0,
                step=10.0,
                key="oxygen_system_eur_per_kw",
                disabled=not st.session_state.oxygen_enabled,
            )

    with st.expander("H₂-Aufbereitung", expanded=False):
        c1, c2 = st.columns(2)
        with c1:
            st.checkbox("H₂ wird verdichtet", key="compression_enabled")
        with c2:
            st.number_input(
                "Verdichtersystemkosten [€/kW]",
                min_value=0.0,
                max_value=100_000.0,
                step=10.0,
                key="compressor_system_eur_per_kw",
                disabled=not st.session_state.compression_enabled,
            )

    with st.expander("Batteriesystem", expanded=False):
        c1, c2 = st.columns(2)
        with c1:
            st.checkbox("Batteriesystem wird genutzt", key="battery_enabled")
            st.number_input(
                "Faktor für Speicherkapazität [kWh pro kW Systemleistung]",
                min_value=0.0,
                max_value=100.0,
                step=0.1,
                key="battery_capacity_factor_kwh_per_kw",
                disabled=not st.session_state.battery_enabled,
            )
        with c2:
            st.number_input(
                "Installierte Leistung [kW]",
                min_value=0.0,
                max_value=1_000_000.0,
                step=100.0,
                key="battery_power_kw",
                disabled=not st.session_state.battery_enabled,
            )
            st.number_input(
                "Investitionskosten [€/kWh]",
                min_value=0.0,
                max_value=100_000.0,
                step=10.0,
                key="battery_invest_eur_per_kwh",
                disabled=not st.session_state.battery_enabled,
            )

    with st.expander("Ersatzinvestitionen & Finanzierung", expanded=True):
        c1, c2, c3, c4 = st.columns(4)

        with c1:
            st.number_input(
                "Stackersatz [€/kW]",
                min_value=0.0,
                max_value=100_000.0,
                step=10.0,
                key="stack_replacement_specific_eur_per_kw",
            )

        with c2:
            st.slider(
                "Kalkulationszins [-]",
                min_value=0.0,
                max_value=0.30,
                step=0.005,
                key="discount_rate",
            )

        with c3:
            st.slider(
                "Fremdkapitalzins [-]",
                min_value=0.0,
                max_value=0.30,
                step=0.005,
                key="debt_interest_rate",
            )

        with c4:
            st.slider(
                "Eigenkapitalquote [-]",
                min_value=0.0,
                max_value=1.0,
                step=0.01,
                key="equity_share",
            )

# ============================================================
# Tab 3: OPEX
# ============================================================

with tabs[2]:
    st.subheader("OPEX")

    with st.expander("Wartung & Instandhaltung", expanded=True):
        c1, c2 = st.columns(2)

        with c1:
            st.slider(
                "Gesamt Wartung & Instandhaltung [% von CAPEX Total]",
                min_value=0.0,
                max_value=10.0,
                step=0.05,
                key="maintenance_share_of_capex",
                format="%.2f",
            )

        with c2:
            st.slider(
                "Preisentwicklung pro Jahr [%]",
                min_value=0.0,
                max_value=10.0,
                step=0.05,
                key="maintenance_escalation_per_year",
                format="%.2f",
            )

    with st.expander("Personalkosten", expanded=True):
        c1, c2 = st.columns(2)

        with c1:
            st.number_input(
                "Gesamt Personalkosten abzgl. W&I [€ / a]",
                min_value=0.0,
                max_value=100_000_000.0,
                step=1_000.0,
                key="personnel_eur_per_year",
            )

        with c2:
            st.slider(
                "Preisentwicklung pro Jahr [%]",
                min_value=0.0,
                max_value=10.0,
                step=0.05,
                key="personnel_escalation_per_year",
                format="%.2f",
            )

    with st.expander("Rückstellungen (ohne Stacktausch)", expanded=True):
        c1, c2, c3 = st.columns(3)

        with c1:
            st.slider(
                "Ersatzinvest. Restliche Anlage [% von CAPEX Total]",
                min_value=0.0,
                max_value=10.0,
                step=0.05,
                key="reserve_remaining_plant_share_of_capex",
                format="%.2f",
            )

        with c2:
            st.slider(
                "Rückbau [% von CAPEX Total]",
                min_value=0.0,
                max_value=10.0,
                step=0.05,
                key="reserve_decommissioning_share_of_capex",
                format="%.2f",
            )

        with c3:
            st.slider(
                "Preisentwicklung pro Jahr [%]",
                min_value=0.0,
                max_value=10.0,
                step=0.05,
                key="reserve_escalation_per_year",
                format="%.2f",
            )

    with st.expander("Wasser", expanded=True):
        c1, c2 = st.columns(2)

        with c1:
            st.number_input(
                "Preis Frischwasser [€ / m³]",
                min_value=0.0,
                max_value=1_000.0,
                step=0.1,
                key="freshwater_price_eur_per_m3",
            )
            st.number_input(
                "Preis Aufbereitung Frischwasser [€ / m³]",
                min_value=0.0,
                max_value=1_000.0,
                step=0.1,
                key="freshwater_treatment_price_eur_per_m3",
            )

        with c2:
            st.number_input(
                "Preis Abwasser [€ / m³]",
                min_value=0.0,
                max_value=1_000.0,
                step=0.1,
                key="wastewater_price_eur_per_m3",
            )
            st.slider(
                "Preisentwicklung pro Jahr [%]",
                min_value=0.0,
                max_value=10.0,
                step=0.05,
                key="water_escalation_per_year",
                format="%.2f",
            )

    with st.expander("Individuelle OPEX", expanded=True):
        c1, c2 = st.columns(2)

        with c1:
            st.slider(
                "Individuelle OPEX [% von CAPEX Total]",
                min_value=0.0,
                max_value=10.0,
                step=0.05,
                key="individual_opex_share_of_capex",
                format="%.2f",
            )

        with c2:
            st.slider(
                "Preisentwicklung pro Jahr [%]",
                min_value=0.0,
                max_value=10.0,
                step=0.05,
                key="individual_opex_escalation_per_year",
                format="%.2f",
            )


# ============================================================
# Tab 4: Strom & Zeitreihen
# ============================================================

with tabs[3]:
    st.subheader("Stromversorgung & Zeitreihen")

    # ------------------------------------------------------------
    # Baseload-PPA
    # ------------------------------------------------------------
    with st.expander("Baseload-PPA", expanded=False):
        c1, c2, c3 = st.columns(3)

        with c1:
            st.checkbox("Baseload-PPA wird genutzt", key="baseload_enabled")

        with c2:
            st.number_input(
                "Baseload-PPA Leistung [kW]",
                min_value=0.0,
                max_value=1_000_000.0,
                step=100.0,
                key="baseload_kw",
                disabled=not st.session_state.baseload_enabled,
            )

        with c3:
            st.number_input(
                "Strompreis Baseload-PPA [€/MWh]",
                min_value=0.0,
                max_value=1_000.0,
                step=1.0,
                key="baseload_price_eur_per_mwh",
                disabled=not st.session_state.baseload_enabled,
            )

        st.slider(
            "Preisentwicklung Strompreis pro Jahr [%]",
            min_value=0.0,
            max_value=20.0,
            step=0.1,
            key="baseload_price_escalation_per_year",
            format="%.1f",
            disabled=not st.session_state.baseload_enabled,
        )

    # ------------------------------------------------------------
    # Pay-as-produced PPAs
    # ------------------------------------------------------------
    with st.expander("Pay-as-Produced PPAs", expanded=False):
        st.markdown("#### PV-PPA")
        c1, c2, c3 = st.columns(3)

        with c1:
            st.checkbox("PV-PPA wird genutzt", key="ppa_pv_enabled")

        with c2:
            st.number_input(
                "PV-PPA Leistung [kW]",
                min_value=0.0,
                max_value=1_000_000.0,
                step=100.0,
                key="ppa_pv_capacity_kw",
                disabled=not st.session_state.ppa_pv_enabled,
            )

        with c3:
            st.number_input(
                "PV-PPA Preis [€/MWh]",
                min_value=0.0,
                max_value=1_000.0,
                step=1.0,
                key="ppa_pv_price_eur_per_mwh",
                disabled=not st.session_state.ppa_pv_enabled,
            )

        st.markdown("#### Wind-PPA")
        c4, c5, c6 = st.columns(3)

        with c4:
            st.checkbox("Wind-PPA wird genutzt", key="ppa_wind_enabled")

        with c5:
            st.number_input(
                "Wind-PPA Leistung [kW]",
                min_value=0.0,
                max_value=1_000_000.0,
                step=100.0,
                key="ppa_wind_capacity_kw",
                disabled=not st.session_state.ppa_wind_enabled,
            )

        with c6:
            st.number_input(
                "Wind-PPA Preis [€/MWh]",
                min_value=0.0,
                max_value=1_000.0,
                step=1.0,
                key="ppa_wind_price_eur_per_mwh",
                disabled=not st.session_state.ppa_wind_enabled,
            )

        st.slider(
            "Preisentwicklung Strompreise pro Jahr [%]",
            min_value=0.0,
            max_value=20.0,
            step=0.1,
            key="ppa_price_escalation_per_year",
            format="%.1f",
        )

    # ------------------------------------------------------------
    # PV-Profil
    # ------------------------------------------------------------
    with st.expander("PV-Profil", expanded=False):
        c1, c2 = st.columns([1, 2])

        with c1:
            if st.button("PV-Demo-Profil laden", key="pv_demo_btn"):
                demo_df = make_demo_timeseries()
                st.session_state.pv_profile_text = timeseries_to_text(demo_df["pv_kwh_per_kw"])

        with c2:
            pv_upload = st.file_uploader("PV-Profil als CSV", type=["csv"], key="pv_profile_csv")
            if pv_upload is not None and st.button("PV-CSV übernehmen", key="pv_csv_btn"):
                try:
                    values = read_numeric_csv_series(pv_upload)
                    if np.any(values < 0) or np.any(values > 1):
                        raise ValueError("PV-Profilwerte müssen zwischen 0 und 1 liegen.")
                    st.session_state.pv_profile_text = timeseries_to_text(values)
                    st.success("PV-CSV in Textfeld übernommen.")
                except Exception as e:
                    st.error(f"PV-CSV konnte nicht gelesen werden: {e}")

        st.text_area(
            "PV-Profil: eine Zahl pro Stunde (0 bis 1)",
            key="pv_profile_text",
            height=220,
        )

        try:
            pv_values = parse_timeseries_text(st.session_state.pv_profile_text, expected_length=8760)
            if np.any(pv_values < 0) or np.any(pv_values > 1):
                raise ValueError("Alle PV-Werte müssen zwischen 0 und 1 liegen.")

            st.session_state.timeseries_df["pv_kwh_per_kw"] = pv_values

            st.success("PV-Profil gültig.")
            st.caption(
                f"8760 Werte | min = {pv_values.min():.3f} | "
                f"max = {pv_values.max():.3f} | Mittelwert = {pv_values.mean():.3f}"
            )
        except Exception as e:
            st.error(f"Fehler im PV-Profil: {e}")

    # ------------------------------------------------------------
    # Wind-Profil
    # ------------------------------------------------------------
    with st.expander("Wind-Profil", expanded=False):
        c1, c2 = st.columns([1, 2])

        with c1:
            if st.button("Wind-Demo-Profil laden", key="wind_demo_btn"):
                demo_df = make_demo_timeseries()
                st.session_state.wind_profile_text = timeseries_to_text(demo_df["wind_kwh_per_kw"])

        with c2:
            wind_upload = st.file_uploader("Wind-Profil als CSV", type=["csv"], key="wind_profile_csv")
            if wind_upload is not None and st.button("Wind-CSV übernehmen", key="wind_csv_btn"):
                try:
                    values = read_numeric_csv_series(wind_upload)
                    if np.any(values < 0) or np.any(values > 1):
                        raise ValueError("Wind-Profilwerte müssen zwischen 0 und 1 liegen.")
                    st.session_state.wind_profile_text = timeseries_to_text(values)
                    st.success("Wind-CSV in Textfeld übernommen.")
                except Exception as e:
                    st.error(f"Wind-CSV konnte nicht gelesen werden: {e}")

        st.text_area(
            "Wind-Profil: eine Zahl pro Stunde (0 bis 1)",
            key="wind_profile_text",
            height=220,
        )

        try:
            wind_values = parse_timeseries_text(st.session_state.wind_profile_text, expected_length=8760)
            if np.any(wind_values < 0) or np.any(wind_values > 1):
                raise ValueError("Alle Wind-Werte müssen zwischen 0 und 1 liegen.")

            st.session_state.timeseries_df["wind_kwh_per_kw"] = wind_values

            st.success("Wind-Profil gültig.")
            st.caption(
                f"8760 Werte | min = {wind_values.min():.3f} | "
                f"max = {wind_values.max():.3f} | Mittelwert = {wind_values.mean():.3f}"
            )
        except Exception as e:
            st.error(f"Fehler im Wind-Profil: {e}")

    # ------------------------------------------------------------
    # Spotmarktbezug
    # ------------------------------------------------------------
    with st.expander("Spotmarktbezug", expanded=False):
        c1, c2, c3 = st.columns(3)

        with c1:
            st.checkbox(
                "Fehlenden Strom auf dem Spotmarkt kaufen",
                key="spot_purchase_enabled",
            )

        with c2:
            st.checkbox(
                "Maximalpreis verwenden",
                key="spot_purchase_price_limit_enabled",
                disabled=not st.session_state.spot_purchase_enabled,
            )

        with c3:
            st.number_input(
                "Maximaler Spotpreis [€/MWh]",
                min_value=-500.0,
                max_value=5_000.0,
                step=1.0,
                key="spot_purchase_price_limit_eur_per_mwh",
                disabled=(
                    not st.session_state.spot_purchase_enabled
                    or not st.session_state.spot_purchase_price_limit_enabled
                ),
            )


    # ------------------------------------------------------------
    # Spotmarktverkauf
    # ------------------------------------------------------------
    with st.expander("Spotmarktverkauf", expanded=False):
        c1, c2, c3 = st.columns(3)

        with c1:
            st.checkbox(
                "Überschüssigen Strom auf dem Spotmarkt verkaufen",
                key="spot_sale_enabled",
            )

        with c2:
            st.checkbox(
                "Minimalpreis verwenden",
                key="spot_sale_price_limit_enabled",
                disabled=not st.session_state.spot_sale_enabled,
            )

        with c3:
            st.number_input(
                "Minimaler Spotpreis [€/MWh]",
                min_value=-500.0,
                max_value=5_000.0,
                step=1.0,
                key="spot_sale_min_price_eur_per_mwh",
                disabled=(
                    not st.session_state.spot_sale_enabled
                    or not st.session_state.spot_sale_price_limit_enabled
                ),
            )

        st.caption(
            "Wenn der Verkauf aktiv ist, wird nicht genutzter PPA-Überschuss stündlich zum angegebenen Spotmarktpreis verkauft. "
            "Wenn ein Minimalpreis verwendet wird, erfolgt der Verkauf nur in Stunden, in denen der Spotpreis mindestens diesen Wert erreicht. "
            "Andernfalls wird der Überschuss abgeregelt bzw. verworfen."
        )

    # ------------------------------------------------------------
    # Spotmarktpreise
    # ------------------------------------------------------------
    with st.expander("Spotmarktpreise", expanded=False):
        c1, c2 = st.columns([1, 2])

        with c1:
            if st.button("Demo-Spotpreise laden", key="spot_demo_btn"):
                demo_df = make_demo_timeseries()
                st.session_state.spot_price_text = timeseries_to_text(demo_df["day_ahead_eur_per_mwh"])

        with c2:
            spot_upload = st.file_uploader("Spotpreise als CSV [€/MWh]", type=["csv"], key="spot_price_csv")
            if spot_upload is not None and st.button("Spotpreis-CSV übernehmen", key="spot_csv_btn"):
                try:
                    values = read_numeric_csv_series(spot_upload)
                    st.session_state.spot_price_text = timeseries_to_text(values)
                    st.success("Spotpreis-CSV in Textfeld übernommen.")
                except Exception as e:
                    st.error(f"Spotpreis-CSV konnte nicht gelesen werden: {e}")

        st.text_area(
            "Spotpreise: eine Zahl pro Stunde [€/MWh]",
            key="spot_price_text",
            height=220,
        )

        try:
            spot_values = parse_timeseries_text(st.session_state.spot_price_text, expected_length=8760)
            st.session_state.timeseries_df["day_ahead_eur_per_mwh"] = spot_values

            st.success("Spotpreis-Zeitreihe gültig.")
            st.caption(
                f"8760 Werte | min = {spot_values.min():.2f} €/MWh | "
                f"max = {spot_values.max():.2f} €/MWh | Mittelwert = {spot_values.mean():.2f} €/MWh"
            )
        except Exception as e:
            st.error(f"Fehler in der Spotpreis-Zeitreihe: {e}")

    # ------------------------------------------------------------
    # Zeitreihen-Vorschau
    # ------------------------------------------------------------
    with st.expander("Zeitreihen-Vorschau", expanded=True):
        preview_df = st.session_state.timeseries_df.copy().reset_index(drop=True)

        # Textfelder noch einmal explizit in den DataFrame übernehmen
        try:
            preview_df["pv_kwh_per_kw"] = parse_timeseries_text(
                st.session_state.pv_profile_text,
                expected_length=8760,
            )
            preview_df["wind_kwh_per_kw"] = parse_timeseries_text(
                st.session_state.wind_profile_text,
                expected_length=8760,
            )
            preview_df["day_ahead_eur_per_mwh"] = parse_timeseries_text(
                st.session_state.spot_price_text,
                expected_length=8760,
            )

            st.session_state.timeseries_df = preview_df.copy()

        except Exception as e:
            st.warning(f"Zeitreihen konnten für die Vorschau nicht vollständig aktualisiert werden: {e}")

        preview_df["Stunde"] = np.arange(1, len(preview_df) + 1)

        def plot_timeseries_interactive(
            df: pd.DataFrame,
            y_col: str,
            title: str,
            y_label: str,
            as_percent: bool = False,
        ):
            y_values = df[y_col] * 100 if as_percent else df[y_col]

            fig = go.Figure()

            fig.add_trace(
                go.Scattergl(
                    x=df["Stunde"],
                    y=y_values,
                    mode="lines",
                    name=y_label,
                )
            )

            fig.update_layout(
                title=title,
                xaxis_title="Stunde des Jahres",
                yaxis_title=y_label,
                height=400,
                margin=dict(l=20, r=20, t=50, b=20),
                hovermode="x unified",
            )

            fig.update_xaxes(rangeslider_visible=True)

            st.plotly_chart(fig, use_container_width=True)

        tab_pv, tab_wind, tab_spot = st.tabs(["PV", "Wind", "Spotmarkt"])

        with tab_pv:
            values = preview_df["pv_kwh_per_kw"]

            c1, c2, c3 = st.columns(3)
            c1.metric("Minimum", f"{(values.min())*100:.3f} %")
            c2.metric("Maximum", f"{(values.max())*100:.3f} %")
            c3.metric("Mittelwert", f"{(values.mean())*100:.3f} %")

            plot_timeseries_interactive(
                preview_df,
                y_col="pv_kwh_per_kw",
                title="PV-Profil über das Jahr",
                y_label="Normierte Leistung [%]",
                as_percent=True
            )

        with tab_wind:
            values = preview_df["wind_kwh_per_kw"]

            c1, c2, c3 = st.columns(3)
            c1.metric("Minimum", f"{(values.min())*100:.3f} %")
            c2.metric("Maximum", f"{(values.max())*100:.3f} %")
            c3.metric("Mittelwert", f"{(values.mean())*100:.3f} %")

            plot_timeseries_interactive(
                preview_df,
                y_col="wind_kwh_per_kw",
                title="Wind-Profil über das Jahr",
                y_label="Normierte Leistung [%]",
                as_percent=True
            )

        with tab_spot:
            values = preview_df["day_ahead_eur_per_mwh"]

            c1, c2, c3 = st.columns(3)
            c1.metric("Minimum", f"{values.min():.2f} €/MWh")
            c2.metric("Maximum", f"{values.max():.2f} €/MWh")
            c3.metric("Mittelwert", f"{values.mean():.2f} €/MWh")

            plot_timeseries_interactive(
                preview_df,
                y_col="day_ahead_eur_per_mwh",
                title="Spotmarktpreise über das Jahr",
                y_label="Spotpreis [€/MWh]",
            )

# ============================================================
# Tab 5: Ergebnisse
# ============================================================

with tabs[4]:
    st.subheader("Ergebnisse")

    def fmt_de(value: float, decimals: int = 2) -> str:
        if value is None:
            return "-"
        return f"{value:,.{decimals}f}".replace(",", "X").replace(".", ",").replace("X", ".")

    def fmt_int_de(value: float) -> str:
        if value is None:
            return "-"
        return f"{value:,.0f}".replace(",", ".")

    def fmt_pct_de(value_fraction: float, decimals: int = 1) -> str:
        if value_fraction is None:
            return "-"
        value_percent = value_fraction * 100.0
        return f"{value_percent:.{decimals}f}".replace(".", ",") + " %"

    bundle = st.session_state.result_bundle
    if bundle is None:
        st.info("Bitte die Berechnung über die Seitenleiste starten.")
    else:
        results = bundle["results"]
        dispatch_df = bundle["dispatch"]
        model_inputs = bundle["inputs"]

        # ----------------------------------------------------
        # Hauptkennzahlen
        # ----------------------------------------------------
        with st.expander("Hauptkennzahlen", expanded=True):
            c1, c2, c3, c4 = st.columns(4)
            c1.metric("LCOH", f"{fmt_de(results['lcoh_eur_per_kg'], 2)} €/kg")
            c2.metric("LCOH", f"{fmt_de(results['lcoh_ct_per_kwh'], 2)} ct/kWh")
            c3.metric("Wasserstoffproduktion", f"{fmt_int_de(results['annual_h2_kg'])} kg/a")
            c4.metric("Ely-Stromverbrauch", f"{fmt_int_de(results['annual_ely_mwh'])} MWh/a")

            c5, c6, c7, c8 = st.columns(4)
            c5.metric("Durchschnittliche Auslastung", fmt_pct_de(results["avg_utilization"], 1))
            c6.metric("Betriebsstunden", f"{fmt_int_de(results['operating_hours'])} h")
            c7.metric("Äquivalente Volllaststunden", f"{fmt_int_de(results['equivalent_full_load_hours'])} h/a")
            c8.metric("Spotmarktkosten", f"{fmt_int_de(results['annual_spot_cost_eur'])} €/a")

        # ----------------------------------------------------
        # Kostenstruktur
        # ----------------------------------------------------
        with st.expander("Kostenstruktur", expanded=True):
            c1, c2, c3, c4 = st.columns(4)

            with c1:
                st.markdown("**CAPEX**")
                st.metric("CAPEX gesamt", f"{fmt_int_de(results['total_capex_eur'])} €")
                st.metric("CAPEX annuisiert", f"{fmt_int_de(results['annualized_capex_eur_per_year'])} €/a")
                st.metric("Stackersatz", f"{fmt_int_de(results['stack_replacement_eur_per_year'])} €/a")

            with c2:
                st.markdown("**OPEX**")
                st.metric("Wartung & Instandhaltung", f"{fmt_int_de(results['maintenance_eur_per_year'])} €/a")
                st.metric("Personalkosten", f"{fmt_int_de(results['personnel_eur_per_year'])} €/a")
                st.metric("Rückstellungen", f"{fmt_int_de(results['reserves_total_eur_per_year'])} €/a")
                st.metric("Wasserkosten", f"{fmt_int_de(results['water_eur_per_year'])} €/a")
                st.metric("Individuelle OPEX", f"{fmt_int_de(results['individual_opex_eur_per_year'])} €/a")

            with c3:
                st.markdown("**Stromkosten**")
                st.metric("Stromkosten brutto", f"{fmt_int_de(results['annual_power_cost_gross_eur'])} €/a")
                st.metric("Stromerlöse", f"{fmt_int_de(results['annual_power_revenue_eur'])} €/a")
                st.metric("Stromkosten netto", f"{fmt_int_de(results['annual_power_cost_net_eur'])} €/a")         

            with c4:
                st.markdown("**Gesamtkosten**")
                st.metric("OPEX gesamt", f"{fmt_int_de(results['total_opex_eur_per_year'])} €/a")
                st.metric("Spotmarktkosten", f"{fmt_int_de(results['annual_spot_cost_eur'])} €/a")
                st.metric("Gesamtkosten jährlich", f"{fmt_int_de(results['annual_costs_eur_per_year'])} €/a")

        # ----------------------------------------------------
        # Betriebskennzahlen
        # ----------------------------------------------------
        with st.expander("Betriebskennzahlen", expanded=False):
            c1, c2, c3, c4 = st.columns(4)

            c1.metric("H₂-Energieproduktion", f"{fmt_int_de(results['annual_h2_kwh'])} kWh/a")
            c2.metric("Ely-Stromverbrauch", f"{fmt_int_de(results['annual_ely_kwh'])} kWh/a")
            c3.metric("PPA-Strombezug", f"{fmt_int_de(results['annual_ppa_kwh'])} kWh/a")
            c4.metric("Spot-Strombezug", f"{fmt_int_de(results['annual_spot_kwh'])} kWh/a")

            c5, c6, c7, c8 = st.columns(4)
            c5.metric("Volllaststunden (gezählt)", f"{fmt_int_de(results['full_load_hours_count'])} h")
            c6.metric("Teillaststunden", f"{fmt_int_de(results['partial_load_hours'])} h")
            c7.metric("Wasserbedarf", f"{fmt_de(results['annual_water_demand_m3'], 0)} m³/a")
            c8.metric("Wasserkosten gesamt", f"{fmt_de(results['water_cost_per_m3'], 2)} €/m³")

        # ----------------------------------------------------
        # Visualisierung
        # ----------------------------------------------------
        with st.expander("Visualisierung", expanded=True):
            col1, col2 = st.columns(2)

            with col1:
                st.markdown("### Dauerlinie der Auslastung")
                duration_curve = np.sort(dispatch_df["utilization"].to_numpy())[::-1] * 100.0
                duration_df = pd.DataFrame(
                    {
                        "Stundenrang": np.arange(1, len(duration_curve) + 1),
                        "Auslastung [%]": duration_curve,
                    }
                )
                st.line_chart(duration_df.set_index("Stundenrang"))

            with col2:
                st.markdown("### Strommix (Jahressummen)")
                mix_df = pd.DataFrame(
                    {
                        "Kategorie": [
                            "PPA verfügbar",
                            "PPA genutzt",
                            "Spotbezug",
                            "Spotverkauf",
                            "Abregelung",
                            "Systemverbrauch",
                            "Ely-Verbrauch",
                        ],
                        "MWh/a": [
                            dispatch_df["ppa_available_kwh"].sum() / 1000.0,
                            dispatch_df["ppa_used_kwh"].sum() / 1000.0,
                            dispatch_df["spot_purchase_kwh"].sum() / 1000.0,
                            dispatch_df["spot_sale_kwh"].sum() / 1000.0,
                            dispatch_df["curtailed_kwh"].sum() / 1000.0,
                            dispatch_df["system_consumption_kwh"].sum() / 1000.0,
                            dispatch_df["ely_consumption_kwh"].sum() / 1000.0,
                        ],
                    }
                ).set_index("Kategorie")
                st.bar_chart(mix_df)

            st.markdown("### Kostenstruktur (jährlich)")
            cost_breakdown_df = pd.DataFrame(
                {
                    "Kategorie": [
                        "CAPEX annuisiert",
                        "Stackersatz",
                        "Wartung & Instandhaltung",
                        "Personal",
                        "Rückstellungen",
                        "Wasser",
                        "Individuelle OPEX",
                        "Baseload-PPA",
                        "PV-PPA",
                        "Wind-PPA",
                        "Spotbezug",
                        "Spotverkauf (Erlös)",
                    ],
                    "€/a": [
                        results["annualized_capex_eur_per_year"],
                        results["stack_replacement_eur_per_year"],
                        results["maintenance_eur_per_year"],
                        results["personnel_eur_per_year"],
                        results["reserves_total_eur_per_year"],
                        results["water_eur_per_year"],
                        results["individual_opex_eur_per_year"],
                        results["annual_baseload_cost_eur"],
                        results["annual_pv_ppa_cost_eur"],
                        results["annual_wind_ppa_cost_eur"],
                        results["annual_spot_purchase_cost_eur"],
                        -results["annual_spot_sale_revenue_eur"],
                    ],
                }
            ).set_index("Kategorie")
            st.bar_chart(cost_breakdown_df)

        # ----------------------------------------------------
        # Ergebnisübersicht als Tabelle
        # ----------------------------------------------------
        with st.expander("Ergebnisübersicht als Tabelle", expanded=False):
            summary_df = pd.DataFrame(
                [
                    ["LCOH", f"{fmt_de(results['lcoh_eur_per_kg'], 2)} €/kg"],
                    ["LCOH", f"{fmt_de(results['lcoh_ct_per_kwh'], 2)} ct/kWh"],
                    ["Wasserstoffproduktion", f"{fmt_int_de(results['annual_h2_kg'])} kg/a"],
                    ["Ely-Stromverbrauch", f"{fmt_int_de(results['annual_ely_mwh'])} MWh/a"],
                    ["Durchschnittliche Auslastung", fmt_pct_de(results["avg_utilization"], 1)],
                    ["Betriebsstunden", f"{fmt_int_de(results['operating_hours'])} h"],
                    ["Äquivalente Volllaststunden", f"{fmt_int_de(results['equivalent_full_load_hours'])} h/a"],
                    ["CAPEX annuisiert", f"{fmt_int_de(results['annualized_capex_eur_per_year'])} €/a"],
                    ["OPEX gesamt", f"{fmt_int_de(results['total_opex_eur_per_year'])} €/a"],
                    ["Gesamtkosten jährlich", f"{fmt_int_de(results['annual_costs_eur_per_year'])} €/a"],
                ],
                columns=["Kennzahl", "Wert"],
            )
            st.dataframe(summary_df, use_container_width=True, hide_index=True)

        # ----------------------------------------------------
        # Export
        # ----------------------------------------------------
        with st.expander("Export", expanded=False):
            export_json = json.dumps(
                {
                    "system": asdict(model_inputs.system),
                    "capex": asdict(model_inputs.capex),
                    "opex": asdict(model_inputs.opex),
                    "power": asdict(model_inputs.power),
                    "results": results,
                },
                indent=2,
            ).encode("utf-8")

            st.download_button(
                "Ergebnisse als JSON herunterladen",
                export_json,
                "lcoh_results.json",
                "application/json",
            )

            export_csv = pd.DataFrame([results]).to_csv(index=False, sep=";", decimal=",").encode("utf-8")
            st.download_button(
                "KPIs als CSV herunterladen",
                export_csv,
                "lcoh_kpis.csv",
                "text/csv",
            )