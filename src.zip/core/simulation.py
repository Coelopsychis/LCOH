from __future__ import annotations

import numpy as np
import pandas as pd

from core.models import ModelInputs
from core.timeseries import validate_timeseries
from core.constants import KWH_PER_KG_H2

def build_dispatch(inputs: ModelInputs, ts: pd.DataFrame) -> pd.DataFrame:
    """
    Hourly dispatch logic:

    1. Baseload-PPA available if active.
    2. PV/Wind pay-as-produced PPA available if active.
    3. All PPA energy is paid for, regardless of whether it is used.
    4. Missing electricity can optionally be purchased from the spot market.
    5. Surplus electricity can optionally be sold to the spot market.
    6. If utilization is below minimum load, the system is switched off.
    """
    validate_timeseries(ts)

    system_kw = float(inputs.system.system_power_kw)
    ely_kw = float(inputs.system.electrolyzer_power_kw)
    min_load = float(inputs.system.min_load_fraction)
    power = inputs.power

    if system_kw <= 0:
        raise ValueError("Systemleistung muss größer als 0 sein.")
    if ely_kw <= 0:
        raise ValueError("Elektrolyseurleistung muss größer als 0 sein.")
    if ely_kw > system_kw:
        raise ValueError("Elektrolyseurleistung darf nicht größer als Systemleistung sein.")

    n = len(ts)
    price_spot = ts["day_ahead_eur_per_mwh"].to_numpy(dtype=float)

    # ------------------------------------------------------------
    # 1) Verfügbare PPA-Mengen
    # ------------------------------------------------------------
    baseload_available_kwh = np.full(
        n,
        power.baseload_kw if power.baseload_enabled else 0.0,
        dtype=float,
    )

    pv_available_kwh = (
        ts["pv_kwh_per_kw"].to_numpy(dtype=float) * power.ppa_pv_capacity_kw
        if power.ppa_pv_enabled
        else np.zeros(n, dtype=float)
    )

    wind_available_kwh = (
        ts["wind_kwh_per_kw"].to_numpy(dtype=float) * power.ppa_wind_capacity_kw
        if power.ppa_wind_enabled
        else np.zeros(n, dtype=float)
    )

    ppa_available_kwh = (
        baseload_available_kwh
        + pv_available_kwh
        + wind_available_kwh
    )

    # ------------------------------------------------------------
    # 2) Spotkauf zur Auffüllung bis Volllast
    # ------------------------------------------------------------
    missing_to_full_load_kwh = np.maximum(system_kw - ppa_available_kwh, 0.0)

    if power.spot_purchase_enabled:
        if power.spot_purchase_price_limit_enabled:
            spot_purchase_allowed = price_spot <= power.spot_purchase_price_limit_eur_per_mwh
        else:
            spot_purchase_allowed = np.ones(n, dtype=bool)

        spot_purchase_kwh = np.where(
            spot_purchase_allowed,
            missing_to_full_load_kwh,
            0.0,
        )
    else:
        spot_purchase_kwh = np.zeros(n, dtype=float)

    total_available_kwh = ppa_available_kwh + spot_purchase_kwh

    # ------------------------------------------------------------
    # 3) Systemverbrauch und Mindestlast
    # ------------------------------------------------------------
    utilization_raw = np.clip(total_available_kwh / system_kw, 0.0, 1.0)
    utilization = np.where(utilization_raw >= min_load, utilization_raw, 0.0)

    system_consumption_kwh = utilization * system_kw
    ely_share = ely_kw / system_kw
    ely_consumption_kwh = system_consumption_kwh * ely_share

    # ------------------------------------------------------------
    # 4) Energiezuordnung: Was wurde genutzt?
    # ------------------------------------------------------------
    remaining_demand = system_consumption_kwh.copy()

    baseload_used_kwh = np.minimum(baseload_available_kwh, remaining_demand)
    remaining_demand -= baseload_used_kwh

    pv_used_kwh = np.minimum(pv_available_kwh, remaining_demand)
    remaining_demand -= pv_used_kwh

    wind_used_kwh = np.minimum(wind_available_kwh, remaining_demand)
    remaining_demand -= wind_used_kwh

    spot_used_kwh = np.minimum(spot_purchase_kwh, remaining_demand)
    remaining_demand -= spot_used_kwh

    ppa_used_kwh = baseload_used_kwh + pv_used_kwh + wind_used_kwh

    # ------------------------------------------------------------
    # 5) Überschüsse
    # ------------------------------------------------------------
    ppa_surplus_kwh = np.maximum(
        ppa_available_kwh - ppa_used_kwh,
        0.0,
    )

    if power.spot_sale_enabled:
        if power.spot_sale_price_limit_enabled:
            spot_sale_allowed = price_spot >= power.spot_sale_min_price_eur_per_mwh
        else:
            spot_sale_allowed = np.ones(n, dtype=bool)

        spot_sale_kwh = np.where(
            spot_sale_allowed,
            ppa_surplus_kwh,
            0.0,
        )

        curtailed_kwh = ppa_surplus_kwh - spot_sale_kwh
    else:
        spot_sale_kwh = np.zeros(n, dtype=float)
        curtailed_kwh = ppa_surplus_kwh

    # ------------------------------------------------------------
    # 6) Kosten und Erlöse
    # ------------------------------------------------------------
    # Wichtig: PPA-Kosten werden auf die gesamte verfügbare/vereinbarte Energie gerechnet.
    baseload_cost_eur = baseload_available_kwh * power.baseload_price_eur_per_mwh / 1000.0
    pv_ppa_cost_eur = pv_available_kwh * power.ppa_pv_price_eur_per_mwh / 1000.0
    wind_ppa_cost_eur = wind_available_kwh * power.ppa_wind_price_eur_per_mwh / 1000.0

    spot_purchase_cost_eur = spot_used_kwh * price_spot / 1000.0
    spot_sale_revenue_eur = spot_sale_kwh * price_spot / 1000.0

    power_cost_gross_eur = (
        baseload_cost_eur
        + pv_ppa_cost_eur
        + wind_ppa_cost_eur
        + spot_purchase_cost_eur
    )

    power_revenue_eur = spot_sale_revenue_eur
    power_cost_net_eur = power_cost_gross_eur - power_revenue_eur

    # ------------------------------------------------------------
    # 7) Ergebnis-DataFrame
    # ------------------------------------------------------------
    result = ts.copy()

    result["baseload_available_kwh"] = baseload_available_kwh
    result["pv_available_kwh"] = pv_available_kwh
    result["wind_available_kwh"] = wind_available_kwh
    result["ppa_available_kwh"] = ppa_available_kwh

    result["baseload_used_kwh"] = baseload_used_kwh
    result["pv_used_kwh"] = pv_used_kwh
    result["wind_used_kwh"] = wind_used_kwh
    result["ppa_used_kwh"] = ppa_used_kwh

    result["spot_purchase_kwh"] = spot_used_kwh
    result["spot_sale_kwh"] = spot_sale_kwh
    result["curtailed_kwh"] = curtailed_kwh

    result["utilization"] = utilization
    result["system_consumption_kwh"] = system_consumption_kwh
    result["ely_consumption_kwh"] = ely_consumption_kwh

    result["baseload_cost_eur"] = baseload_cost_eur
    result["pv_ppa_cost_eur"] = pv_ppa_cost_eur
    result["wind_ppa_cost_eur"] = wind_ppa_cost_eur
    result["spot_purchase_cost_eur"] = spot_purchase_cost_eur
    result["spot_sale_revenue_eur"] = spot_sale_revenue_eur

    result["power_cost_gross_eur"] = power_cost_gross_eur
    result["power_revenue_eur"] = power_revenue_eur
    result["power_cost_net_eur"] = power_cost_net_eur

    return result

def compute_operation_kpis(inputs: ModelInputs, dispatch: pd.DataFrame) -> dict:
    annual_ely_kwh = float(dispatch["ely_consumption_kwh"].sum())
    annual_h2_kwh = annual_ely_kwh * inputs.system.avg_efficiency_h2_per_el
    annual_h2_kg = (
        annual_h2_kwh / KWH_PER_KG_H2
        if KWH_PER_KG_H2 > 0
        else 0.0
    )

    utilization = dispatch["utilization"].to_numpy(dtype=float)
    avg_utilization = float(utilization.mean())
    operating_hours = int(np.sum(utilization > 0.0))
    full_load_hours_count = int(np.sum(utilization == 1.0))
    partial_load_hours = operating_hours - full_load_hours_count
    equivalent_full_load_hours = 8760 * avg_utilization

    annual_baseload_available_kwh = float(dispatch["baseload_available_kwh"].sum())
    annual_pv_available_kwh = float(dispatch["pv_available_kwh"].sum())
    annual_wind_available_kwh = float(dispatch["wind_available_kwh"].sum())
    annual_ppa_available_kwh = float(dispatch["ppa_available_kwh"].sum())

    annual_baseload_used_kwh = float(dispatch["baseload_used_kwh"].sum())
    annual_pv_used_kwh = float(dispatch["pv_used_kwh"].sum())
    annual_wind_used_kwh = float(dispatch["wind_used_kwh"].sum())
    annual_ppa_used_kwh = float(dispatch["ppa_used_kwh"].sum())

    annual_spot_purchase_kwh = float(dispatch["spot_purchase_kwh"].sum())
    annual_spot_sale_kwh = float(dispatch["spot_sale_kwh"].sum())
    annual_curtailed_kwh = float(dispatch["curtailed_kwh"].sum())

    annual_baseload_cost_eur = float(dispatch["baseload_cost_eur"].sum())
    annual_pv_ppa_cost_eur = float(dispatch["pv_ppa_cost_eur"].sum())
    annual_wind_ppa_cost_eur = float(dispatch["wind_ppa_cost_eur"].sum())
    annual_spot_purchase_cost_eur = float(dispatch["spot_purchase_cost_eur"].sum())
    annual_spot_sale_revenue_eur = float(dispatch["spot_sale_revenue_eur"].sum())

    annual_power_cost_gross_eur = float(dispatch["power_cost_gross_eur"].sum())
    annual_power_revenue_eur = float(dispatch["power_revenue_eur"].sum())
    annual_power_cost_net_eur = float(dispatch["power_cost_net_eur"].sum())

    return {
        "annual_ely_kwh": annual_ely_kwh,
        "annual_ely_mwh": annual_ely_kwh / 1000.0,
        "annual_h2_kwh": annual_h2_kwh,
        "annual_h2_kg": annual_h2_kg,

        "avg_utilization": avg_utilization,
        "operating_hours": operating_hours,
        "full_load_hours_count": full_load_hours_count,
        "partial_load_hours": partial_load_hours,
        "equivalent_full_load_hours": equivalent_full_load_hours,

        "annual_baseload_available_kwh": annual_baseload_available_kwh,
        "annual_pv_available_kwh": annual_pv_available_kwh,
        "annual_wind_available_kwh": annual_wind_available_kwh,
        "annual_ppa_available_kwh": annual_ppa_available_kwh,

        "annual_baseload_used_kwh": annual_baseload_used_kwh,
        "annual_pv_used_kwh": annual_pv_used_kwh,
        "annual_wind_used_kwh": annual_wind_used_kwh,
        "annual_ppa_used_kwh": annual_ppa_used_kwh,

        "annual_spot_purchase_kwh": annual_spot_purchase_kwh,
        "annual_spot_sale_kwh": annual_spot_sale_kwh,
        "annual_curtailed_kwh": annual_curtailed_kwh,

        "annual_baseload_cost_eur": annual_baseload_cost_eur,
        "annual_pv_ppa_cost_eur": annual_pv_ppa_cost_eur,
        "annual_wind_ppa_cost_eur": annual_wind_ppa_cost_eur,
        "annual_spot_purchase_cost_eur": annual_spot_purchase_cost_eur,
        "annual_spot_sale_revenue_eur": annual_spot_sale_revenue_eur,

        "annual_power_cost_gross_eur": annual_power_cost_gross_eur,
        "annual_power_revenue_eur": annual_power_revenue_eur,
        "annual_power_cost_net_eur": annual_power_cost_net_eur,

        # Aliasse für bestehende Ergebnisdarstellung
        "annual_ppa_kwh": annual_ppa_available_kwh,
        "annual_spot_kwh": annual_spot_purchase_kwh,
        "annual_spot_cost_eur": annual_spot_purchase_cost_eur,
        "annual_power_costs_eur": annual_power_cost_net_eur,
    }